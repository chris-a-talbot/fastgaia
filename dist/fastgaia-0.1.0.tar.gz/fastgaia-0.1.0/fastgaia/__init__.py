# fastgaia/__init__.py

from .main import infer_locations
